package me.joe.mpe.framework.wrapped;

public interface IPlayerListHud {
   boolean hasFooterOrHeader();
}

package me.joe.mpe.framework.wrapped;

import net.minecraft.text.Text;

public interface IPlayerListHeaderS2CPacket {
   void setHeader(Text var1);

   void setFooter(Text var1);
}

package me.joe.mpe.impl.managers;

import me.joe.api.manage.impl.ArrayListManager;
import me.joe.mpe.api.Command;
import me.joe.mpe.impl.commands.tpa.TpaCommand;

public class CommandManager extends ArrayListManager<Command> {
   /*
   public CommandManager() {
      this.init();
      this.addCommands();
   }

   public void register() {
      this.getElements().forEach(Command::register);
   }

   public void addCommands() {
      this.add(new Command[]{new HomeCommand(),new WildCommand(),new PosHUDCommand(),new TeamsCommand(),new PosCommand(),new MsgCommand(),new VanishCommand(),new FormatCommand(),new SeenCommand(),new StuckCommand(),new HealCommand(),new GodCommand(),new InvseeCommand(),new ParticlesCommand(),new WeatherCommand(),new TimeCommand(),new FlyCommand(),new RTPCommand(),new ReportCommand(),new HatCommand(),new KitCommand(),new FlyCommand(),new InfoCommand(),new RanksCommand(),new BroadcastCommand(),new BanCommand(),new RulesCommand(), new DelHomeCommand(), new HomesCommand(), new SetHomeCommand(), new DiscordCommand(), new DonateCommand(), new HelpCommand(), new PingCommand(), new VoteCommand(), new SetSpawnCommand(), new SpawnCommand(), new TpaCommand(), new TpaHereCommand(), new TpaRequestCommands(), new DelWarpCommand(), new SetWarpCommand(), new WarpCommand(), new WarpsCommand(), new DelZoneCommand(), new SetZoneCommand(), new ZonesCommand(), new AnvilCommand(), new EChestCommand(), new NickCommand(), new UnNickCommand(), new ClearChatCommands(), new GamemodeCommand(), new KickCommand(), new MutePlayerCommand(), new IgnoreCommand(), new PlayerNickCommand(), new RankCommand(), new TpsCommand()});
   }
    */
}

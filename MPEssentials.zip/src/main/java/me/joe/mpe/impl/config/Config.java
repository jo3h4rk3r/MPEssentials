package me.joe.mpe.impl.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.*;

public class Config {

    public void save() throws IOException {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        File config = new File("config/EssentialSettings.json");
        if(!config.exists()){
            config.createNewFile();
        }
        try (FileWriter file = new FileWriter("config/EssentialSettings.json")) {
            file.write(gson.toJson(this));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void load() throws IOException{
        File config1 = new File("config/EssentialSettings.json");
        if(!config1.exists()){
            this.save();
        }
        FileReader reader;

    }
}
package me.joe.mpe.impl.utilities;

public class PlayerUtility {
}

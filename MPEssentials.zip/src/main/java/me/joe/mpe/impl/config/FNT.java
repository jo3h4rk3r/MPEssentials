package me.joe.mpe.impl.config;

import com.mojang.authlib.GameProfile;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;

import java.util.UUID;

public class FNT {
    public Text getDisplayNameNick() {

        return null;
    }
}

package me.joe.mpe.impl.tablist;

public class TabHUD {


    public String header = "&b&lSurvivalMP &8&l| &aOnline&8: &f#PLAYERSONLINE\n";
    public String footer = "\n&3TPS&8:&f #TPS &8&l| &3MSPT&8:&f #MSPT";
    //public String footer = "\n &aTPS&8:&3 #TPS &7| &aMSPT&8:&3 #MSPT &7| &aPING&8:&3 #PING \n";

    public boolean enableColor = true;


}

package me.joe.api.manage;

public abstract class AbstractManager {
   public abstract void init();
}

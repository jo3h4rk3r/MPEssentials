package me.joe.api.event.data;

public enum EventType {
   PRE,
   ON,
   POST,
   SEND,
   RECEIVE;
}

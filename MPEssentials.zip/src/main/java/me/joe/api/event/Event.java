package me.joe.api.event;

public abstract class Event {
   private String TODO = "probably add a IListener so that you can choose when a listener should invoke events, instead of having to unbind, this should improve the performance alot";
   private final String DESCRIPTION = "Idk im pretty sure this shit doo doo but whatever";
}

package me.joe.api.event.data.interfaces;

public interface Cancelable {
   boolean isCanceled();

   void setCanceled(boolean var1);
}
